package Enums;

public enum VehicleType {
    CAR,
    MOTORCYCLE,
    CARRIAGE
}