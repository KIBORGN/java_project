package Enums;

public enum PaymentSchedule {
    MONTHLY,
    SEMIANNUAL,
    ANNUAL
}
