package Enums;

public enum CoverageType {
    ACCIDENT,
    EARTHQUAKE,
    FIRE,
    THEFT
}
