package Enums;

public enum EngineType {
    DIESEL,
    PETROL,
    ELECTRIC
}
